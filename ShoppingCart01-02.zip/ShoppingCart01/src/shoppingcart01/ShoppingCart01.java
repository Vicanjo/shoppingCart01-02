
package shoppingcart01;

public class ShoppingCart01 {
    public static void main(String[] args) {
        // Declare and initialize String variables.  Do not initialize message yet.
         String custName = "Pedro ";
         String itemDesc = "quiere comprar un carro chido xd";
         String message;
        // Assign the message variable 
        message = custName + itemDesc;
        
        // Print and run the code
        System.out.println(message);
    }
}
